package com.team23.prototype1.model;

import org.springframework.stereotype.Component;

@Component
public class PartTypeModel {

    private int partTypeId;
    private String partTypeDescription;
    private String customField1, customField2, customField3, customField4, customField5;

    public int getPartTypeId() {
        return partTypeId;
    }

    public void setPartTypeId(int partTypeId) {
        this.partTypeId = partTypeId;
    }

    public String getPartTypeDescription() {
        return partTypeDescription;
    }

    public void setPartTypeDescription(String partTypeDescription) {
        this.partTypeDescription = partTypeDescription;
    }

    public String getCustomField1() {
        return customField1;
    }

    public void setCustomField1(String customField1) {
        this.customField1 = customField1;
    }

    public String getCustomField2() {
        return customField2;
    }

    public void setCustomField2(String customField2) {
        this.customField2 = customField2;
    }

    public String getCustomField3() {
        return customField3;
    }

    public void setCustomField3(String customField3) {
        this.customField3 = customField3;
    }

    public String getCustomField4() {
        return customField4;
    }

    public void setCustomField4(String customField4) {
        this.customField4 = customField4;
    }

    public String getCustomField5() {
        return customField5;
    }

    public void setCustomField5(String customField5) {
        this.customField5 = customField5;
    }

}
