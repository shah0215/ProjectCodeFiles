package com.team23.prototype1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prototype1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
